Compiled from 0.3a nicehash/nheqminer sources for win x64 CUDA 8.0 and cards with cc6.2, cc6.1, cc5.2, cc5.0, cc3.5, cc3.0, cc2.x (cc2.x deprecated, but still should work, cc - compute capability - list: https://en.wikipedia.org/wiki/CUDA )

You need lastest driver for cuda 8.0 !!
You need at least 1GB gpu memory


chronosek

if you are not poor tip welcome (btc) 1AHMpXk8NLWqw1bZfU3qmQiWYi1W7yFnyi