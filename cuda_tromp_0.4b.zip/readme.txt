
 Compiled with Visual Studio 2013 update 5 from 0.4b nicehash/nheqminer sources for windowns x64 

- cuda_tromp.dll - compiled with CUDA 8.0 and AVX for cards with cc6.2, cc6.1, cc5.2, cc5.0, cc3.5, cc3.0, cc2.x (cc2.x deprecated, but still should work, use option -cv 0)
- cuda_tromp_75.dll - compiled with CUDA 7.5 and SSE2 for cards with cc5.2, cc5.0, cc3.5, cc3.0, cc2.x (use option -cv 1)


cc - compute capability - gpu list: https://en.wikipedia.org/wiki/CUDA

Info:
- You need replace files what you want use with files in your nheqminer directory and remeber use right -cv option
- Best choice is CUDA 8.0, use CUDA 7.5 version only when you have older driver or your cpu not have AVX instructions
- if your driver not support right cuda version  or gpu not have at least 1GB gpu memory or you try use AVX when you not have - you will get 0 sol/s
- try -cb,ct options, for me best was -cb 64 -ct 64 (you should experiment with values), but if you use older card and still have problems then try lower that values (-cb 2 -ct 8 etc)
- works only with x64 nheqminer


chronosek

if you are not poor tip welcome (btc) 1AHMpXk8NLWqw1bZfU3qmQiWYi1W7yFnyi


PS. Special thanks to Tromp and nicehash developers